import java.awt.image.BufferedImage;

final class Diamond extends Form implements Visitable {
    private Point centru;
    private int diagonalaVerticala;
    private int diagonalaOrizontala;

    Diamond(final String nume, final int x, final int y, final int diag1,
            final int diag2, final int re, final int ri) {
        super(nume, re, ri);
        this.centru = new Point(x, y);
        this.diagonalaOrizontala = diag1;
        this.diagonalaVerticala = diag2;
    }

    public int getCentruX() {
        return centru.getX();
    }

    public int getCentruY() {
        return centru.getY();
    }

    public int getDiagonalaVerticala() {
        return this.diagonalaVerticala;
    }

    public int getDiagonalaOrizontala() {
        return this.diagonalaOrizontala;
    }

    public void accept(final Visitor v, final BufferedImage buff) {
        v.visit(this, buff);
    }
}
