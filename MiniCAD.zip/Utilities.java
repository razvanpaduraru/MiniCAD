import java.awt.image.BufferedImage;
import java.util.LinkedList;

final class Utilities {

    private final int c1 = 16;
    private final int c2 = 48;
    private final int c3 = 57;
    private final int c4 = 65;
    private final int c5 = 70;
    private final int c6 = 55;
    private final int c7 = 97;
    private final int c8 = 102;
    private final int c9 = 87;
    private final int c10 = 3;
    private final int c11 = 4;
    private final int c12 = 6;
    private final int c13 = 10;


    String decToString(final int x) {
        String rez = "";
        int copy = x;
        while (copy != 0) {
            int cifra = copy % c1;
            rez += "" + cifra;
            copy = copy / c1;
        }
        String rez2 = "";
        for (int i = rez.length() - 1; i >= 0; --i) {
            rez2 += rez.charAt(i);
        }
        return rez2;
    }
    int hexToDec(final String rgb, final int alpha) {
        String ajut = decToString(alpha);
        ajut += rgb.substring(1);
        int rez = 0;
        for (int i = ajut.length() - 1; i >= 0; --i) {
            if (ajut.charAt(i) >= c2 && ajut.charAt(i) <= c3) {
                rez += Math.pow(c1, ajut.length() - 1 - i)
                        * (ajut.charAt(i) - c2);
            }
            if (ajut.charAt(i) >= c4 && ajut.charAt(i) <= c5) {
                rez += Math.pow(c1, ajut.length() - 1 - i)
                        * (ajut.charAt(i) - c6);
            }
            if (ajut.charAt(i) >= c7 && ajut.charAt(i) <= c8) {
                rez += Math.pow(c1, ajut.length() - 1 - i)
                        * (ajut.charAt(i) - c9);
            }
        }
        return rez;
    }

    int sign(final int x) {
        if (x < 0) {
            return -1;
        } else {
            if (x == 0) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    void bresenhamAlgorithm(final int x1, final int y1, final int x2,
                            final int y2, final int rgb,
                            final BufferedImage buf) {
        int x = x1;
        int y = y1;
        int deltaX = Math.abs(x2 - x1);
        int deltaY = Math.abs(y2 - y1);
        int s1 = sign(x2 - x1);
        int s2 = sign(y2 - y1);
        boolean interchanged;

        if (deltaY > deltaX) {
            int aux = deltaY;
            deltaY = deltaX;
            deltaX = aux;
            interchanged = true;
        } else {
            interchanged = false;
        }
        int error = 2 * deltaY - deltaX;

        for (int i = 0; i <= deltaX; ++i) {
            if (x < buf.getWidth() && x >= 0 && y < buf.getHeight() && y >= 0) {
                buf.setRGB(x, y, rgb);
            }
            while (error > 0) {
                if (interchanged) {
                    x = x + s1;
                } else {
                    y = y + s2;
                }
                error = error - 2 * deltaX;
            }

            if (interchanged) {
                y = y + s2;
            } else {
                x = x + s1;
            }
            error = error + 2 * deltaY;
        }
    }

    void drawCircle(final int xC, final int yC,
                     final int x, final int y,
                     final int rgb, final BufferedImage buff) {
        if (xC + x < buff.getWidth()
                && yC + y < buff.getHeight()
                && yC + y >= 0 && xC + x >= 0) {
            buff.setRGB(xC + x, yC + y, rgb);
        }
        if (xC - x < buff.getWidth()
                && yC + y < buff.getHeight()
                && xC - x >= 0 && yC + y >= 0) {
            buff.setRGB(xC - x, yC + y, rgb);
        }
        if (xC + x < buff.getWidth()
                && yC - y < buff.getHeight()
                && yC - y >= 0 && xC + x >= 0) {
            buff.setRGB(xC + x, yC - y, rgb);
        }
        if (xC - x < buff.getWidth()
                && yC - y < buff.getHeight()
                && xC - x >= 0 && yC - y >= 0) {
            buff.setRGB(xC - x, yC - y, rgb);
        }
        if (xC + y < buff.getWidth()
                && yC + x < buff.getHeight()
                && yC + x >= 0 && xC + y >= 0) {
            buff.setRGB(xC + y, yC + x, rgb);
        }
        if (xC - y < buff.getWidth()
                && yC + x < buff.getHeight()
                && xC - y >= 0 && yC + x >= 0) {
            buff.setRGB(xC - y, yC + x, rgb);
        }
        if (xC + y < buff.getWidth()
                && yC - x < buff.getHeight()
                && yC - x >= 0 && xC + y >= 0) {
            buff.setRGB(xC + y, yC - x, rgb);
        }
        if (xC - y < buff.getWidth()
                && yC - x < buff.getHeight()
                && xC - y >= 0 && yC - x >= 0) {
            buff.setRGB(xC - y, yC - x, rgb);
        }
    }

    void bresenhamCircle(final int xC, final int yC,
                         final int r, final int rgb,
                         final BufferedImage buff) {
        int x = 0;
        int y = r;
        int decision = c10 - 2 * r;

        while (x <= y) {
            drawCircle(xC, yC, x, y, rgb, buff);
            ++x;
            if (decision > 0) {
                --y;
                decision = decision + c11 * (x - y) + c13;
            } else {
                decision = decision + c11 * (x) + c12;
            }

            drawCircle(xC, yC, x, y, rgb, buff);

        }
    }

    void fooldFill(final int xG, final int yG,
                   final int rgbPtColorare,
                   final int rgbContur,
                   final BufferedImage buff) {
        int x = xG;
        int y = yG;
        int r = buff.getRGB(x, y);

        if (r == rgbPtColorare) {
            return;
        }

        if (rgbContur != rgbPtColorare) {
            buff.setRGB(x, y, rgbPtColorare);
            LinkedList<Point> points = new LinkedList<>();

            Point p = new Point(x, y);

            points.add(p);
            while (!points.isEmpty()) {
                Point scos = points.removeFirst();

                int culoare = buff.getRGB(scos.getX(), scos.getY());

                if (culoare != rgbContur) {
                    Point adaugare = new Point(scos.getX() - 1, scos.getY());
                    if (adaugare.getX() < buff.getWidth()
                            && adaugare.getX() >= 0
                            && adaugare.getY() < buff.getHeight()
                            && adaugare.getY() >= 0) {
                        int cul = buff.getRGB(adaugare.getX(), adaugare.getY());
                        if (adaugare.getX() < buff.getWidth()
                                && adaugare.getX() >= 0
                                && adaugare.getY() < buff.getHeight()
                                && adaugare.getY() >= 0
                                && cul != rgbPtColorare
                                && cul != rgbContur) {
                            buff.setRGB(scos.getX() - 1,
                                    scos.getY(), rgbPtColorare);
                            points.addLast(adaugare);
                        }
                    }
                }

                if (culoare != rgbContur) {
                    Point adaugare = new Point(scos.getX() + 1, scos.getY());
                    if (adaugare.getX() < buff.getWidth()
                            && adaugare.getX() >= 0
                            && adaugare.getY() < buff.getHeight()
                            && adaugare.getY() >= 0) {
                        int cul = buff.getRGB(adaugare.getX(), adaugare.getY());
                        if (adaugare.getX() < buff.getWidth()
                                && adaugare.getX() >= 0
                                && adaugare.getY() < buff.getHeight()
                                && adaugare.getY() >= 0
                                && cul != rgbPtColorare && cul != rgbContur) {
                            buff.setRGB(scos.getX() + 1,
                                    scos.getY(), rgbPtColorare);
                            points.addLast(adaugare);
                        }
                    }
                }

                if (culoare != rgbContur) {
                    Point adaugare = new Point(scos.getX(), scos.getY() - 1);
                    if (adaugare.getX() < buff.getWidth()
                            && adaugare.getX() >= 0
                            && adaugare.getY() < buff.getHeight()
                            && adaugare.getY() >= 0) {
                        int cul = buff.getRGB(adaugare.getX(), adaugare.getY());
                        if (adaugare.getX() < buff.getWidth()
                                && adaugare.getX() >= 0
                                && adaugare.getY() < buff.getHeight()
                                && adaugare.getY() >= 0
                                && cul != rgbPtColorare
                                && cul != rgbContur) {
                            buff.setRGB(scos.getX(),
                                    scos.getY() - 1, rgbPtColorare);
                            points.addLast(adaugare);
                        }
                    }
                }

                if (culoare != rgbContur) {
                    Point adaugare = new Point(scos.getX(), scos.getY() + 1);
                    if (adaugare.getX() < buff.getWidth()
                            && adaugare.getX() >= 0
                            && adaugare.getY() < buff.getHeight()
                            && adaugare.getY() >= 0) {
                        int cul = buff.getRGB(adaugare.getX(), adaugare.getY());
                        if (adaugare.getX() < buff.getWidth()
                                && adaugare.getX() >= 0
                                && adaugare.getY() < buff.getHeight()
                                && adaugare.getY() >= 0
                                && cul != rgbPtColorare
                                && cul != rgbContur) {
                            buff.setRGB(scos.getX(),
                                    scos.getY() + 1, rgbPtColorare);
                            points.addLast(adaugare);
                        }
                    }
                }
            }
        } else {
            buff.setRGB(x, y, rgbPtColorare);
            LinkedList<Point> points = new LinkedList<>();

            Point p = new Point(x, y);

            points.add(p);
            while (!points.isEmpty()) {
                Point scoate = points.removeFirst();


                int culoare = buff.getRGB(scoate.getX(), scoate.getY());
                if (culoare == rgbContur) {
                    Point adaugare = new Point(scoate.getX() - 1,
                            scoate.getY());
                    if (adaugare.getX() < buff.getWidth()
                            && adaugare.getX() >= 0
                            && adaugare.getY() < buff.getHeight()
                            && adaugare.getY() >= 0) {
                        int cul = buff.getRGB(adaugare.getX(),
                                adaugare.getY());
                        if (adaugare.getX() < buff.getWidth()
                                && adaugare.getX() >= 0
                                && adaugare.getY() < buff.getHeight()
                                && adaugare.getY() >= 0
                                && cul != rgbContur) {
                            buff.setRGB(scoate.getX() - 1,
                                    scoate.getY(), rgbPtColorare);
                            points.addLast(adaugare);
                        }
                    }
                }

                if (culoare == rgbContur) {
                    Point adaugare = new Point(scoate.getX() + 1,
                            scoate.getY());
                    if (adaugare.getX() < buff.getWidth()
                            && adaugare.getX() >= 0
                            && adaugare.getY() < buff.getHeight()
                            && adaugare.getY() >= 0) {
                        int cul = buff.getRGB(adaugare.getX(),
                                adaugare.getY());
                        if (adaugare.getX() < buff.getWidth()
                                && adaugare.getX() >= 0
                                && adaugare.getY() < buff.getHeight()
                                && adaugare.getY() >= 0
                                && cul != rgbContur) {
                            buff.setRGB(scoate.getX() + 1,
                                    scoate.getY(), rgbPtColorare);
                            points.addLast(adaugare);
                        }
                    }
                }

                if (culoare == rgbContur) {
                    Point adaugare = new Point(scoate.getX(),
                            scoate.getY() - 1);
                    if (adaugare.getX() < buff.getWidth()
                            && adaugare.getX() >= 0
                            && adaugare.getY() < buff.getHeight()
                            && adaugare.getY() >= 0) {
                        int cul = buff.getRGB(adaugare.getX(),
                                adaugare.getY());
                        if (adaugare.getX() < buff.getWidth()
                                && adaugare.getX() >= 0
                                && adaugare.getY() < buff.getHeight()
                                && adaugare.getY() >= 0
                                && cul != rgbContur) {
                            buff.setRGB(scoate.getX(),
                                    scoate.getY() - 1,
                                    rgbPtColorare);
                            points.addLast(adaugare);
                        }
                    }
                }

                if (culoare == rgbContur) {
                    Point adaugare = new Point(scoate.getX(),
                            scoate.getY() + 1);
                    if (adaugare.getX() < buff.getWidth()
                            && adaugare.getX() >= 0
                            && adaugare.getY() < buff.getHeight()
                            && adaugare.getY() >= 0) {
                        int cul = buff.getRGB(adaugare.getX(),
                                adaugare.getY());
                        if (adaugare.getX() < buff.getWidth()
                                && adaugare.getX() >= 0
                                && adaugare.getY() < buff.getHeight()
                                && adaugare.getY() >= 0
                                && cul != rgbContur) {
                            buff.setRGB(scoate.getX(),
                                    scoate.getY() + 1, rgbPtColorare);
                            points.addLast(adaugare);
                        }
                    }
                }
            }
        }
    }
}
