final class Point {
    private int x;
    private int y;

    Point(final int xP, final int yP) {
        this.x = xP;
        this.y = yP;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }
}
