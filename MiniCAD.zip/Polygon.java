import java.awt.image.BufferedImage;
import java.util.Vector;

final class Polygon extends Form implements Visitable {
    private int numarPuncte;
    private Vector<Point> puncte;

    Polygon(final String nume, final int nrpct,
            final Vector<Point> y, final int re, final int ri) {
        super(nume, re, ri);
        this.numarPuncte = nrpct;
        this.puncte = new Vector<Point>(nrpct);
        for (int i = 0; i < this.numarPuncte; ++i) {
            Point z = new Point(y.get(i).getX(), y.get(i).getY());
            this.puncte.add(z);
        }
    }

    public Vector<Point> getPuncte() {
        return this.puncte;
    }

    public int getNumarPuncte() {
        return this.numarPuncte;
    }

    public void accept(final Visitor v, final BufferedImage buff) {
        v.visit(this, buff);
    }
}
