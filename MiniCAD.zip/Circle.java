import java.awt.image.BufferedImage;

final class Circle extends Form implements Visitable {
    private Point center;
    private int razaC;

    Circle(final String nume, final int x, final int y,
           final int raza, final int ri, final int re) {
        super(nume, re, ri);
        this.center = new Point(x, y);
        this.razaC = raza;
    }

    public int getCenterX() {
        return this.center.getX();
    }

    public int getCenterY() {
        return this.center.getY();
    }

    public int getRaza() {
        return this.razaC;
    }

    public void accept(final Visitor v, final BufferedImage buff) {
        v.visit(this, buff);
    }
}
