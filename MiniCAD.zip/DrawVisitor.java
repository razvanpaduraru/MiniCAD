import java.awt.image.BufferedImage;

final class DrawVisitor implements Visitor {

    // aceasta clasa serveste la desenarea fiecarui tip
    // de forma in functie de parametrul primit

    private final int ct = 3;

    @Override
    public void visit(final Circle c, final BufferedImage buff) {
        Utilities ut = new Utilities();

        int x = c.getCenterX();
        int y = c.getCenterY();
        int raza = c.getRaza();

        ut.bresenhamCircle(x, y, raza, c.getFinalRGBext(), buff);
        ut.fooldFill(c.getCenterX(), c.getCenterY(),
                c.getFinalRGBint(), c.getFinalRGBext(), buff);
    }

    @Override
    public void visit(final Diamond d, final BufferedImage buff) {
        Utilities ut = new Utilities();

        int dim1 = (int) ((float) d.getDiagonalaVerticala() / (float) 2);
        int dim2 = (int) ((float) d.getDiagonalaOrizontala() / (float) 2);

        int x1 = d.getCentruX();
        int y1 = d.getCentruY() - dim1;

        int x2 = d.getCentruX() + dim2;
        int y2 = d.getCentruY();

        int x3 = d.getCentruX();
        int y3 = d.getCentruY() + dim1;

        int x4 = d.getCentruX() - dim2;
        int y4 = d.getCentruY();

        ut.bresenhamAlgorithm(x3, y3, x2, y2, d.getFinalRGBext(), buff);
        ut.bresenhamAlgorithm(x2, y2, x1, y1, d.getFinalRGBext(), buff);
        ut.bresenhamAlgorithm(x1, y1, x4, y4, d.getFinalRGBext(), buff);
        ut.bresenhamAlgorithm(x4, y4, x3, y3, d.getFinalRGBext(), buff);
        ut.fooldFill(d.getCentruX(), d.getCentruY(),
                d.getFinalRGBint(), d.getFinalRGBext(), buff);
    }

    @Override
    public void visit(final Line l, final BufferedImage buff) {
        Utilities ut = new Utilities();
        ut.bresenhamAlgorithm(l.getP1x(), l.getP1y(),
                l.getP2x(), l.getP2y(), l.getFinalRGBext(), buff);
    }

    @Override
    public void visit(final Polygon p, final BufferedImage buff) {
        Utilities ut = new Utilities();

        for (int i = 0; i < p.getNumarPuncte() - 1; ++i) {
            ut.bresenhamAlgorithm(p.getPuncte().get(i).getX(),
                    p.getPuncte().get(i).getY(),
                    p.getPuncte().get(i + 1).getX(),
                    p.getPuncte().get(i + 1).getY(),
                    p.getFinalRGBext(), buff);
        }
        ut.bresenhamAlgorithm(p.getPuncte().get(p.getNumarPuncte() - 1).getX(),
                p.getPuncte().get(p.getNumarPuncte() - 1).getY(),
                p.getPuncte().get(0).getX(),
                p.getPuncte().get(0).getY(),
                p.getFinalRGBext(), buff);

        int xG = 0;
        for (int i = 0; i < p.getNumarPuncte(); ++i) {
            xG += p.getPuncte().get(i).getX();
        }

        xG = (int) ((float) xG / p.getNumarPuncte());


        int yG = 0;
        for (int i = 0; i < p.getNumarPuncte(); ++i) {
            yG += p.getPuncte().get(i).getY();
        }

        yG = (int) ((float) yG / p.getNumarPuncte());

        ut.fooldFill(xG, yG, p.getFinalRGBint(), p.getFinalRGBext(), buff);
    }

    @Override
    public void visit(final Rectangle r, final BufferedImage buff) {
        Utilities ut = new Utilities();
        int xC1 = r.getPunctX();
        int yC1 = r.getPunctY();
        int xC2, yC2, xC3, yC3, xC4, yC4;
        int latura1 = r.getLungime();
        int latura2 = r.getLatime();
        // verificare daca se iese din canvas
        if (latura1 + xC1 >= buff.getWidth()) {
            xC2 = buff.getWidth() - 1;
            xC3 = xC2;
            xC4 = xC1;
        } else {
            xC2 = xC1 + latura1 - 1;
            xC3 = xC2;
            xC4 = xC1;
        }
        if (latura2 + yC1 >= buff.getHeight()) {
            yC2 = yC1;
            yC3 = yC2 + buff.getHeight() - 1 - yC1;
            yC4 = yC3;
        } else {
            yC2 = yC1;
            yC3 = yC2 + latura2 - 1;
            yC4 = yC3;
        }
        // desenare laturi
        ut.bresenhamAlgorithm(xC1, yC1, xC2, yC2, r.getFinalRGBext(), buff);
        ut.bresenhamAlgorithm(xC2, yC2, xC3, yC3, r.getFinalRGBext(), buff);
        ut.bresenhamAlgorithm(xC3, yC3, xC4, yC4, r.getFinalRGBext(), buff);
        ut.bresenhamAlgorithm(xC4, yC4, xC1, yC1, r.getFinalRGBext(), buff);
        int dim1 = r.getLatime();
        int dim2 = r.getLungime();
        // verificarea iesirii din canvas
        if (yC1 + r.getLatime() >= buff.getHeight()) {
            dim1 = buff.getHeight() - 1 - yC1;
        }
        if (xC1 + dim2 >= buff.getWidth()) {
            dim2 = buff.getWidth() - 1 - xC1;
        }
        if (dim2 != r.getLungime() && dim1 == r.getLatime()) {
            for (int i = xC1 + 1; i <= xC1 + dim2; ++i) {
                for (int j = yC1 + 1; j <= yC1 + dim1 - 2; ++j) {
                    buff.setRGB(i, j, r.getFinalRGBint());
                }
            }
        }

        if (dim1 != r.getLatime() && dim2 == r.getLungime()) {
            for (int i = xC1 + 1; i <= xC1 + dim2 - 2; ++i) {
                for (int j = yC1 + 1; j <= yC1 + dim1; ++j) {
                    buff.setRGB(i, j, r.getFinalRGBint());
                }
            }
        }

        if (dim1 != r.getLatime() && dim2 != r.getLungime()) {
            for (int i = xC1 + 1; i <= xC1 + dim2; ++i) {
                for (int j = yC1 + 1; j <= yC1 + dim1; ++j) {
                    buff.setRGB(i, j, r.getFinalRGBint());
                }
            }
        }

        if ((dim2 == r.getLungime()) && (dim1 == r.getLatime())) {
            for (int i = xC1 + 1; i <= xC1 + dim2 - 2; ++i) {
                for (int j = yC1 + 1; j <= yC1 + dim1 - 2; ++j) {
                    buff.setRGB(i, j, r.getFinalRGBint());
                }
            }
        }

    }

    @Override
    public void visit(final Square s, final BufferedImage buff) {
        Utilities ut = new Utilities();
        int xC1 = s.getPunctX();
        int yC1 = s.getPunctY();
        int xC2, yC2, xC3, yC3, xC4, yC4;
        int latura1 = s.getDimensiuneLatura();
        int latura2 = s.getDimensiuneLatura();
        if (latura1 + xC1 >= buff.getWidth()) {
            xC2 = buff.getWidth() - 1;
            xC3 = xC2;
            xC4 = xC1;
        } else {
            xC2 = xC1 + latura1 - 1;
            xC3 = xC2;
            xC4 = xC1;
        }
        if (latura2 + yC1 >= buff.getHeight()) {
            yC2 = yC1;
            yC3 = yC2 + buff.getHeight() - 1 - yC1;
            yC4 = yC3;
        } else {
            yC2 = yC1;
            yC3 = yC2 + latura2 - 1;
            yC4 = yC3;
        }

        ut.bresenhamAlgorithm(xC1, yC1, xC2, yC2, s.getFinalRGBext(), buff);
        ut.bresenhamAlgorithm(xC2, yC2, xC3, yC3, s.getFinalRGBext(), buff);
        ut.bresenhamAlgorithm(xC3, yC3, xC4, yC4, s.getFinalRGBext(), buff);
        ut.bresenhamAlgorithm(xC4, yC4, xC1, yC1, s.getFinalRGBext(), buff);
        int dim1 = s.getDimensiuneLatura();
        int dim2 = s.getDimensiuneLatura();
        if (yC1 + s.getDimensiuneLatura() > buff.getHeight()) {
            dim1 = buff.getHeight() - 1 - yC1;
        }
        if (xC1 + s.getDimensiuneLatura() > buff.getWidth()) {
            dim2 = buff.getWidth() - 1 - xC1;
        }
        if (dim2 != s.getDimensiuneLatura()
                && (dim1 != s.getDimensiuneLatura())) {
            for (int i = xC1 + 1; i <= xC1 + dim2; ++i) {
                for (int j = yC1 + 1; j <= yC1 + dim1; ++j) {
                    buff.setRGB(i, j, s.getFinalRGBint());
                }
            }
        }

        if (dim1 != s.getDimensiuneLatura()
                && dim2 == s.getDimensiuneLatura()) {
            for (int i = xC1 + 1; i <= xC1 + dim2 - 2; ++i) {
                for (int j = yC1 + 1; j <= yC1 + dim1; ++j) {
                    buff.setRGB(i, j, s.getFinalRGBint());
                }
            }
        }

        if (dim2 != s.getDimensiuneLatura()
                && (dim1 == s.getDimensiuneLatura())) {
            for (int i = xC1 + 1; i <= xC1 + dim2; ++i) {
                for (int j = yC1 + 1; j <= yC1 + dim1 - 2; ++j) {
                    buff.setRGB(i, j, s.getFinalRGBint());
                }
            }
        }

        if ((dim2 == s.getDimensiuneLatura())
                && (dim1 == s.getDimensiuneLatura())) {
            for (int i = xC1 + 1; i < xC1 + dim2 - 1; ++i) {
                for (int j = yC1 + 1; j < yC1 + dim1 - 1; ++j) {
                    buff.setRGB(i, j, s.getFinalRGBint());
                }
            }
        }
    }

    @Override
    public void visit(final Triangle t, final BufferedImage buff) {
        Utilities ut = new Utilities();

        ut.bresenhamAlgorithm(t.getP1X(), t.getP1Y(),
                t.getP2X(), t.getP2Y(), t.getFinalRGBext(), buff);
        ut.bresenhamAlgorithm(t.getP2X(), t.getP2Y(),
                t.getP3X(), t.getP3Y(), t.getFinalRGBext(), buff);
        ut.bresenhamAlgorithm(t.getP3X(), t.getP3Y(),
                t.getP1X(), t.getP1Y(), t.getFinalRGBext(), buff);

        int xG = (int) ((float) (t.getP1X()
                + t.getP2X() + t.getP3X()) / ct);
        int yG = (int) ((float) (t.getP1Y()
                + t.getP2Y() + t.getP3Y()) / ct);

        ut.fooldFill(xG, yG, t.getFinalRGBint(), t.getFinalRGBext(), buff);
    }

    @Override
    public void visit(final Form f, final BufferedImage buff) {

    }
}
