import java.awt.image.BufferedImage;

public interface Visitor {
    void visit(Circle c, BufferedImage buff);
    void visit(Diamond d, BufferedImage buff);
    void visit(Line l, BufferedImage buff);
    void visit(Polygon p, BufferedImage buff);
    void visit(Rectangle r, BufferedImage buff);
    void visit(Square s, BufferedImage buff);
    void visit(Triangle t, BufferedImage buff);
    void visit(Form f, BufferedImage buff);
}
