import fileio.FileSystem;

import java.io.IOException;
import java.util.Vector;

final class Factory {
    public Form verifType(final String type, final FileSystem b) {
        // aici se realizeaza citirea
        // si returnarea tipului
        // dorit de forma
        Utilities ut = new Utilities();
        if (type.compareTo("LINE") == 0) {
            try {
                int x1 = b.nextInt();
                int y1 = b.nextInt();
                int x2 = b.nextInt();
                int y2 = b.nextInt();
                String rgb = b.nextWord();
                int a = b.nextInt();
                int r = ut.hexToDec(rgb, a);
                return new Line(type, x1, y1, x2, y2, a, r);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            if (type.compareTo("SQUARE") == 0) {
                try {
                    int x1 = b.nextInt();
                    int y1 = b.nextInt();
                    int dimlat = b.nextInt();
                    String rgb1 = b.nextWord();
                    int a1 = b.nextInt();
                    String rgb2 = b.nextWord();
                    int a2 = b.nextInt();
                    int r1 = ut.hexToDec(rgb1, a1);
                    int r2 = ut.hexToDec(rgb2, a2);
                    return new Square(type, x1, y1, dimlat, r2, r1);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                if (type.compareTo("RECTANGLE") == 0) {
                    try {
                        int x1 = b.nextInt();
                        int y1 = b.nextInt();
                        int latime = b.nextInt();
                        int lungime = b.nextInt();
                        String rgb1 = b.nextWord();
                        int a1 = b.nextInt();
                        String rgb2 = b.nextWord();
                        int a2 = b.nextInt();
                        int r1 = ut.hexToDec(rgb1, a1);
                        int r2 = ut.hexToDec(rgb2, a2);
                        return new Rectangle(type, x1, y1, latime,
                                lungime, r1, r2);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    if (type.compareTo("TRIANGLE") == 0) {
                        try {
                            int x1 = b.nextInt();
                            int y1 = b.nextInt();
                            int x2 = b.nextInt();
                            int y2 = b.nextInt();
                            int x3 = b.nextInt();
                            int y3 = b.nextInt();
                            String rgb1 = b.nextWord();
                            int a1 = b.nextInt();
                            String rgb2 = b.nextWord();
                            int a2 = b.nextInt();
                            int r1 = ut.hexToDec(rgb1, a1);
                            int r2 = ut.hexToDec(rgb2, a2);
                            return new Triangle(x1, y1, x2, y2, x3, y3, r1, r2);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    } else {
                        if (type.compareTo("DIAMOND") == 0) {
                            try {
                                int x1 = b.nextInt();
                                int y1 = b.nextInt();
                                int d1 = b.nextInt();
                                int d2 = b.nextInt();
                                String rgb1 = b.nextWord();
                                int a1 = b.nextInt();
                                String rgb2 = b.nextWord();
                                int a2 = b.nextInt();
                                int r1 = ut.hexToDec(rgb1, a1);
                                int r2 = ut.hexToDec(rgb2, a2);
                                return new Diamond(type, x1, y1,
                                        d1, d2, r1, r2);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        } else {
                            if (type.compareTo("POLYGON") == 0) {
                                try {
                                    int nr = b.nextInt();
                                    Vector<Point> pct = new Vector<Point>(nr);
                                    for (int i = 0; i < nr; ++i) {
                                        int x = b.nextInt();
                                        int y = b.nextInt();
                                        Point z = new Point(x, y);
                                        pct.add(z);
                                    }
                                    String rgb1 = b.nextWord();
                                    int a1 = b.nextInt();
                                    String rgb2 = b.nextWord();
                                    int a2 = b.nextInt();
                                    int r1 = ut.hexToDec(rgb1, a1);
                                    int r2 = ut.hexToDec(rgb2, a2);
                                    return new Polygon(type, nr, pct, r1, r2);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                if (type.compareTo("CIRCLE") == 0) {
                                    try {
                                        int x1 = b.nextInt();
                                        int y1 = b.nextInt();
                                        int raza = b.nextInt();
                                        String rgb1 = b.nextWord();
                                        int a1 = b.nextInt();
                                        String rgb2 = b.nextWord();
                                        int a2 = b.nextInt();
                                        int r1 = ut.hexToDec(rgb1, a1);
                                        int r2 = ut.hexToDec(rgb2, a2);
                                        return new Circle(type, x1, y1,
                                                raza, r2, r1);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                } else {
                                    return null;
                                }
                            }
                        }
                    }
                }
            }
        }
        return null;
    }
}
