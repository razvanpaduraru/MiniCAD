//import java.nio.file.FileSystem;
import fileio.FileSystem;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Vector;

final class Main {

    private Main() {

    }

    public static void main(final String[] args) {
        String input = args[0];
        String output = "drawing.png";
        FileSystem a = null;
        Factory f = new Factory();
        try {
            Visitor dr = new DrawVisitor();
            a = new FileSystem(input, output);
            int numarForme = a.nextInt();
            Vector<Form> forme = new Vector<Form>(numarForme - 1);

            // construire canvas
            String nume = a.nextWord();
            int inaltime = a.nextInt();
            int latime = a.nextInt();
            String rgb = a.nextWord();
            int aC = a.nextInt();
            Canvas canvas = Canvas.getCanvas(inaltime, latime, rgb);

            // construire vector de forme
            for (int i = 0; i < numarForme - 1; ++i) {
                nume = a.nextWord();
                Form forma = f.verifType(nume, a);
                forme.add(forma);
            }

            BufferedImage x = new BufferedImage(canvas.getLatime(),
                    canvas.getInaltime(), BufferedImage.TYPE_INT_ARGB);

            Utilities ut = new Utilities();

            int rgbF = ut.hexToDec(rgb, aC);
            // colorare canvas
            for (int i = 0; i < x.getWidth(); ++i) {
                for (int j = 0; j < x.getHeight(); ++j) {
                    x.setRGB(i, j, rgbF);
                }
            }
            // desenare forme folosind
            // visitor-pattern
            for (int i = 0; i < forme.size(); ++i) {
                forme.get(i).accept(dr, x);
            }

            ImageIO.write(x, "png", new java.io.File(output));
            a.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
