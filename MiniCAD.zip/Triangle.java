import java.awt.image.BufferedImage;

final class Triangle extends Form implements Visitable {
    private Point punct1;
    private Point punct2;
    private Point punct3;

    Triangle(final int x1, final int y1, final int x2,
             final int y2, final int x3,
             final int y3, final int re, final int ri) {
        super("TRIANGLE", re, ri);
        this.punct1 = new Point(x1, y1);
        this.punct2 = new Point(x2, y2);
        this.punct3 = new Point(x3, y3);
    }

    public int getP1X() {
        return punct1.getX();
    }

    public int getP1Y() {
        return punct1.getY();
    }

    public int getP2X() {
        return punct2.getX();
    }

    public int getP2Y() {
        return punct2.getY();
    }

    public int getP3X() {
        return punct3.getX();
    }

    public int getP3Y() {
        return punct3.getY();
    }

    public void accept(final Visitor v, final BufferedImage buff) {
        v.visit(this, buff);
    }
}
