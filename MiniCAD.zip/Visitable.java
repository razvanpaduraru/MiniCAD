import java.awt.image.BufferedImage;

interface Visitable {
    void accept(Visitor v, BufferedImage buff);
}
