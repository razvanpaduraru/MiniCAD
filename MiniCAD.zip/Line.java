import java.awt.image.BufferedImage;

final class Line extends Form implements Visitable {
    private Point punct1;
    private Point punct2;
    private int aL;

    Line(final String nume, final int x1, final int y1, final int x2,
         final int y2, final int a, final int re) {
        super(nume, re, 0);
        this.punct1 = new Point(x1, y1);
        this.punct2 = new Point(x2, y2);
        this.aL = a;
    }

    public int getP1x() {
        return this.punct1.getX();
    }

    public int getP1y() {
        return this.punct1.getY();
    }

    public int getP2x() {
        return this.punct2.getX();
    }

    public int getP2y() {
        return this.punct2.getY();
    }

    public int getaL() {
        return aL;
    }

    public void accept(final Visitor v, final BufferedImage buff) {
        v.visit(this, buff);
    }
}
