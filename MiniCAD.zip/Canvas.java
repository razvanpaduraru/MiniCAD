
final class Canvas {
    private static Canvas canvas = null;
    private int inaltimeC;
    private int latimeC;
    private String rgbC;

    private Canvas(final int inaltime, final int latime,
                   final String rgb) {
        this.inaltimeC = inaltime;
        this.latimeC = latime;
        this.rgbC = rgb;
    }

    public int getInaltime() {
        return this.inaltimeC;
    }

    public int getLatime() {
        return this.latimeC;
    }

    public static Canvas getCanvas(final int inaltime, final int latime,
                                   final String rgb) {
        if (canvas == null) {
            canvas = new Canvas(inaltime, latime, rgb);
        }
        return canvas;
    }
}
