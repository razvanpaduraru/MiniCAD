import java.awt.image.BufferedImage;

public class Form {
    private String nume;
    private int finalRGBint;
    private int finalRGBext;

    Form() {
        this.nume = null;
    }

    Form(final String numeNou, final int re, final int ri) {
        this.finalRGBext = re;
        this.finalRGBint = ri;
        this.nume = numeNou;
    }

    void accept(final Visitor v, final BufferedImage buff) {
        v.visit(this, buff);
    }

    public final String getName() {
        return this.nume;
    }

    public final int getFinalRGBint() {
        return this.finalRGBint;
    }

    public final int getFinalRGBext() {
        return this.finalRGBext;
    }
}
