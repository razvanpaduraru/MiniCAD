import java.awt.image.BufferedImage;

final class Square extends Form implements Visitable {
    private Point punctStSus;
    private int dimensiuneLatura;

    Square(final String nume, final int x, final int y,
           final int dimensiuneLaturaC, final int ri, final int re) {
        super(nume, re, ri);
        this.punctStSus = new Point(x, y);
        this.dimensiuneLatura = dimensiuneLaturaC;
    }

    public int getPunctX() {
        return punctStSus.getX();
    }

    public int getPunctY() {
        return punctStSus.getY();
    }

    public int getDimensiuneLatura() {
        return dimensiuneLatura;
    }

    public void accept(final Visitor v, final BufferedImage buff) {
        v.visit(this, buff);
    }
}
