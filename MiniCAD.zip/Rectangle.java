import java.awt.image.BufferedImage;

final class Rectangle extends Form implements Visitable {
    private Point punctStSus;
    private int latime;
    private int lungime;

    Rectangle(final String nume, final int x, final int y, final int latimeC,
              final int lungimeC, final int re, final int ri) {
        super(nume, re, ri);
        this.punctStSus = new Point(x, y);
        this.latime = latimeC;
        this.lungime = lungimeC;
    }

    public int getPunctX() {
        return punctStSus.getX();
    }

    public int getPunctY() {
        return punctStSus.getY();
    }

    public int getLatime() {
        return latime;
    }

    public int getLungime() {
        return lungime;
    }

    public void accept(final Visitor v, final BufferedImage buff) {
        v.visit(this, buff);
    }

}
